package com.company;

public class SignIn extends Info{
    public void setSignIn()
    {
        TakeInfo();
        System.out.println("Sign In successful ");
        System.out.println("Log In...");
        LogIn login = new LogIn();
        login.TakeLogInInfo();
    }
}
