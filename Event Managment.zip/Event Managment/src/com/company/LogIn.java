package com.company;
import java.util.*;
public class LogIn extends SignIn {
    Scanner objs=new Scanner(System.in);
    private String Name;
    private String password;
    //Info info=new Info();

    public void setLoginName(String name) {
        Name = name;
    }

    public String getLoginName() {
        return Name;
    }

    public void setLoginPassword(String password) {
        this.password = password;
    }

    public String getLoginPassword() {
        return password;
    }

    public void TakeLogInInfo()
    {
        System.out.println("Enter your name: ");
        String name=objs.nextLine();
        setLoginName(name);
        System.out.println("Enter your Password: ");
        String password=objs.nextLine();
        setLoginPassword(password);
       VerificationLogInInfo();
    }
    public void VerificationLogInInfo()
    {
        if(getLoginName().equals("turjo") && getLoginPassword().equals("20"))
        {
            System.out.println("Login successful ");
            System.out.println("What you want to do?");
            System.out.println("1.Ask for Event management\n2.Want to be a part of Event");
            int c2=objs.nextInt();
            if(c2==1)
            {
                System.out.println("Welcome");
                User user=new User();
                user.user();
            }
            else if(c2==2)
            {
                System.out.println("Welcome.We need you");
                Admin admin=new Admin();
                admin.employee();
            }
            else
            {
                System.out.println("Wrong Info.");
            }
        }
        else
        {
            System.out.println("Wrong Info.");
        }
    }
}
