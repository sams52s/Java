package com.company;
import java.util.*;
public class Main {

    public static void main(String[] args) {
        Scanner objs=new Scanner(System.in);
        System.out.println("***********Welcome to cubic Event management***********");
        System.out.println("***********We can manage your event as you dream***********");
        System.out.println("\n1.Log IN");
        System.out.println("2.Sign In");
        int i1=objs.nextInt();
        if(i1==1) {
            LogIn login = new LogIn();
            login.TakeLogInInfo();
        }
        else if (i1==2)
        {
            System.out.println("\n2.Sign In");
            SignIn sign = new SignIn();
            sign.setSignIn();
        }
        else{
            System.out.println("Wrong Input");
        }

    }
}
