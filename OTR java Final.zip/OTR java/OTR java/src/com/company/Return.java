package com.company;
// Abstract class
abstract class Return {
    // Abstract method (does not have a body)
    public abstract void ItemReturn();
    // Regular method
    public void GetMoneyBack() {
        System.out.println("You Will get 80% money back");
    }
}

